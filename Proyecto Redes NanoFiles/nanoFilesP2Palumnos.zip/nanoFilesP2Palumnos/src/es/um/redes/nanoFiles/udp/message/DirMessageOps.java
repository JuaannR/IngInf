package es.um.redes.nanoFiles.udp.message;

public class DirMessageOps {

	public static final String OPERATION_INVALID = "invalid_operation";
	public static final String OPERATION_PING = "ping";
	public static final String OPERATION_PINGOK = "pingok";
	public static final String OPERATION_PINGERROR = "pingError";
	public static final String OPERATION_SERVE = "serve";
	public static final String OPERATION_SERVEOK = "serveok";
	public static final String OPEARTION_SERVEERROR = "serveError";
	public static final String OPERATION_FILELIST = "filelist";
	public static final String OPERATION_FILELISTOK = "filelistok";
	public static final String OPERATION_FILELISTERROR = "filelistError";
	public static final String OPERATION_DOWNLOAD= "download";
	public static final String OPERATION_DOWNLOADOK= "downloadok";
	public static final String OPERATION_DOWNLOADERROR = "downloaderror";
}
